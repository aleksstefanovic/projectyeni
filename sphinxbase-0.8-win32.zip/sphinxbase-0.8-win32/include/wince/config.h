/* Silvio Moioli: keep only one configuration file */

#include "sphinx_config.h"
